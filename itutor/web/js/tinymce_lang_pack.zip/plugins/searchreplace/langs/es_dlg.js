tinyMCE.addI18n('es.searchreplace_dlg',{
searchnext_desc:"Buscar de nuevo",
notfound:"La b\u00FAsqueda se ha completado. No se encontr\u00F3 el texto introducido.",
search_title:"Buscar",
replace_title:"Buscar/Reemplazar",
allreplaced:"Se ha reemplazado el texto.",
findwhat:"Qu\u00E9 buscar",
replacewith:"Reemplazar por",
direction:"Direcci\u00F3n",
up:"Arriba",
down:"Abajo",
mcase:"Min\u00FAs./May\u00FAs.",
findnext:"Buscar siguiente",
replace:"Reemplazar",
replaceall:"Reemplazar todo"
});